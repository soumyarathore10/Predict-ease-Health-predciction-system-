<?php
// Start the session
session_start();

//Connnection
$host="localhost";
$user="root";
$password='';
$db_name="prediction";


$con=mysqli_connect($host,$user,$password,$db_name);
if(mysqli_connect_errno()){
    die("failed to connect with mysql".mysqli_connect_error());
    
}

if($_SERVER['REQUEST_METHOD'] == 'POST'){
    if(isset($_POST['irregular_periods']) && isset($_POST['heavy_bleeding']) && isset($_POST['skipped_periods']) && isset($_POST['excessive_hairgrowth']) && isset($_POST['weight_gain']) && isset($_POST['hairloss']) && isset($_POST['acne']) && isset($_POST['pain_pelvic']))
    {
        $total_PCOD=8;
    $irregular_periods = $_POST['irregular_periods'];
    $heavy_bleeding = $_POST['heavy_bleeding'];
    $skipped_periods = $_POST['skipped_periods'];
    $excessive_hairgrowth = $_POST['excessive_hairgrowth'];
    $weight_gain = $_POST['weight_gain'];
    $hairloss = $_POST['hairloss'];
    $acne = $_POST['acne'];
    $pain_pelvic = $_POST['pain_pelvic'];

    $sql = "SELECT * FROM `predict` WHERE symptom = '$irregular_periods' OR symptom = '$heavy_bleeding' OR symptom = '$skipped_periods' OR symptom = '$excessive_hairgrowth' OR symptom = '$weight_gain' OR symptom = '$hairloss' OR symptom = '$acne' OR symptom = '$pain_pelvic'";
    $result = mysqli_query($con,$sql);
    $nfr = mysqli_num_rows($result);
    $int_nfr= (float)$nfr;
    function cal_percentage($num_amount, $num_total) {
        $count1 = $num_amount / $num_total;
        $count2 = $count1 * 100;
        $count = number_format($count2, 0);
        return $count;
    }
    $_SESSION["PCOD_percentage"] = cal_percentage($int_nfr, $total_PCOD);
    if($result){
        // echo "Chances of you having High Blood Pressure : ".$_SESSION["PCOD_percentage"].'%<br/>';
        header("location:osteoporosis.html");
    }
    }
}

    ?>