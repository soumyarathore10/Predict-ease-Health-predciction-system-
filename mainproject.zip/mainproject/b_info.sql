-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 26, 2022 at 06:36 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `prediction`
--

-- --------------------------------------------------------

--
-- Table structure for table `b_info`
--

CREATE TABLE `b_info` (
  `id` int(11) NOT NULL,
  `email` varchar(200) NOT NULL,
  `name` varchar(200) NOT NULL,
  `age` int(11) NOT NULL,
  `height` float NOT NULL,
  `weight` float NOT NULL,
  `gender` varchar(30) NOT NULL,
  `blood_pressure` int(11) NOT NULL,
  `diabetes` int(11) NOT NULL,
  `PCOD` int(11) NOT NULL,
  `obesity` int(11) NOT NULL,
  `osteoporosis` int(11) NOT NULL,
  `date_time` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `b_info`
--

INSERT INTO `b_info` (`id`, `email`, `name`, `age`, `height`, `weight`, `gender`, `blood_pressure`, `diabetes`, `PCOD`, `obesity`, `osteoporosis`, `date_time`) VALUES
(74, 'test@gmail.com', 'Anuj', 18, 181, 80, 'male', 56, 57, 0, 25, 33, '2022-07-26 21:52:04'),
(75, 'test@gmail.com', 'Anuj', 18, 181, 80, 'male', 56, 57, 0, 25, 33, '2022-07-26 21:52:24'),
(76, 'test@gmail.com', 'Anuj', 18, 181, 80, 'male', 56, 57, 0, 25, 33, '2022-07-26 21:55:37');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `b_info`
--
ALTER TABLE `b_info`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `b_info`
--
ALTER TABLE `b_info`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=77;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
