<?php
session_start();
?>
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Result!</title>
    <link rel="icon" href="titlelogowhite.png" type="image/icon type">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
  </head>
  <body style="background-color: #5165924e">
    <nav class="navbar navbar-expand-lg navbar-light"  style="background-color: #516392;">
      <a class="navbar-brand mx-3" href="#">
        <img class="logo" src="Predict-ease -logos__white.png" alt="\Stuff logo" style="width: 160px;
      height: 40px;">
    </a>
    <button 
        class="navbar-toggler" 
        type="button" 
        data-bs-toggle="collapse" 
        data-bs-target="#navbarSupportedContent" 
        aria-controls="navbarSupportedContent" 
        aria-expanded="false" 
        aria-label="Toggle navigation"
        >
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav me-auto mb-2 mb-lg-0">
            <li class="nav-item">
            
              <a class="nav-link "  href="lobby.html" style="color: #e0e2d5;">Lobby</a>
              </li>
                
              
          </ul>
         
        </div>
  </nav>
  <div class="px-4 py-2" style="margin-top:20px;">
    <h1 class="display-5 fw-bold " style="font-size: 50px; ">Your Prediction is Here..</h1>
    </div>
    <div class="col-lg-6 mx-4 ">
      <div class=" mb-4 " style="font-size: 22px; margin-top: 0px;">Don't worry it's just a prediction. But, we might suggest a doctor visit. Also we provide a list of doctors that you can contact and make an appointment with. </div>
     
    </div>
 <div class="container-sm " style="background-color:rgba(73, 96, 134, 0.292); border-radius: 00.9rem; box-shadow: 2px 2px 15px ; font-size: 20px; margin-top: 40px; padding: 20px 20px 20px 20px;margin-bottom: 40px;">
<h2>High Blood Pressure</h2>
<h4> <?php 
function cal_percentage($num_amount, $num_total) {
  $count1 = $num_amount / $num_total;
  $count2 = $count1 * 100;
  $count = number_format($count2, 0);
  return $count;
}
$_SESSION["bp_percentage"] = cal_percentage($_SESSION["int_nfr_bp"], $_SESSION["total_bp"]);

echo "Chances of you having High Blood Pressure : ".$_SESSION["bp_percentage"].'%<br/>';?>
</h4>

High blood pressure (hypertension) is a common condition in which the long-term force of the blood against your artery walls is high enough that it may eventually cause health problems, such as heart disease.<br>
  You can have high blood pressure for years without any symptoms. Uncontrolled high blood pressure increases your risk of serious health problems, including heart attack and stroke. Fortunately, high blood pressure can be easily detected. And once you know you have high blood pressure, you can work with your doctor to control it.
   <br><br><h3>Keep in mind:</h3>
    1. Get moving.<br>
    2. Eating fruits, vegetables, and whole grains.<br>
    3. Keep your sodium intake to a minimum.<br>
    4. Stress less.<br>
<h3>Here's a list of doctors concerned with the same.</h3>
1. Doctor_bp1<br>
2. Doctor_bp2<br>
3. Doctor_bp3<br>
4. Doctor_bp4
</div>
      

<div class="container-sm " style="background-color:rgba(73, 96, 134, 0.292); border-radius: 00.9rem; box-shadow: 2px 2px 15px ; font-size: 20px; margin-top: 40px; padding: 20px 20px 20px 20px;margin-bottom: 40px;">
  <h2>Diabetes</h2>
  <h4> <?php
  

$_SESSION["diabetes_percentage"] = cal_percentage($_SESSION["int_nfr_db"], $_SESSION["total_diabetes"]);
  echo "Chances of you having Diabetes : ".$_SESSION["diabetes_percentage"].'%<br/>';?>
</h4>
    
  Diabetes is a disease that occurs when your blood glucose, also called blood sugar, is too high. Blood glucose is your main source of energy and comes from the food you eat. Sometimes your body doesn’t make enough—or any—insulin or doesn’t use insulin well. Glucose then stays in your blood and doesn’t reach your cells. High blood glucose leads to problems such as, heart disease, stroke, kidney disease, eye problems, etc.
   <br><br><h3>Keep in mind:</h3>
    1. Reduce your carb intake.<br>
    2. Reduce your sugar intake.<br>
    3. Exercise more.<br>
    4. Drink more water.<br>
   
  <br>
<h3>Here's a list of doctors concerned with the same.</h3>
1. Doctor_db1<br>
2. Doctor_db2<br>
3. Doctor_db3<br>
4. Doctor_db4
</div>

<div class="container-sm " style="background-color:rgba(73, 96, 134, 0.292); border-radius: 00.9rem; box-shadow: 2px 2px 15px ; font-size: 20px; margin-top: 40px; padding: 20px 20px 20px 20px;margin-bottom: 40px;">
  <h2>PCOS/PCOD</h2>
  <h4><?php echo "Chances of you having PCOD : ".$_SESSION["PCOD_percentage"].'%<br/>';?></h4>
    
  PCOD(Polycystic Ovarian Disease) or PCOS(Polycystic Ovary Syndrome) is a condition that affects women’s ovaries, the reproductive organs that produce progesterone and estrogen hormones that help in regulating the menstrual cycle and also produce small amount of hormones inhibin, relaxin, and male hormones called androgens.If left untreated, PCOD problem in future can lead to type 2 diabetes, obesity and other mental issues due to hormonal imbalance.
   <br><br><h3>Keep in mind:</h3>
    1. Maintaining healthy weight.<br>
    2. Do exercise regularly.<br>
    3. Cut out coffee.<br>
    4. Up your iron intake.<br>
   
  <br>
<h3>Here's a list of doctors concerned with the same.</h3>
1. Doctor_1<br>
2. Doctor_2<br>
3. Doctor_3<br>
4. Doctor_4
</div>

<div class="container-sm " style="background-color:rgba(73, 96, 134, 0.292); border-radius: 00.9rem; box-shadow: 2px 2px 15px ; font-size: 20px; margin-top: 40px; padding: 20px 20px 20px 20px;margin-bottom: 40px;">
  <h2>Obesity</h2>
  <h4><?php

$_SESSION["BMI"]=(float)($_SESSION["weight"]/$_SESSION["height_squared"]);


$_SESSION["obesity_percentage"] = cal_percentage($_SESSION["int_nfr_ob"], $_SESSION["total_obesity"]);
echo "Chances of you being Obese : ".$_SESSION["obesity_percentage"].'%<br/>';
echo "Your Body Mass Index(BMI)  : ". number_format($_SESSION["BMI"],2).'<br/>';
if($_SESSION["age"]>=12){
  if($_SESSION["BMI"]>18.5 && $_SESSION["BMI"]<=25){
      echo "You are fit";
  }
  if($_SESSION["BMI"]<18.5){
    if($_SESSION["BMI"]>16){
      echo "You are thin";
  }
  else{
    echo "you are severly thin";
  }
}
  if($_SESSION["BMI"]>25){
      if($_SESSION["BMI"]>=40){
          echo "You are obese class III.";
      }
      elseif($_SESSION["BMI"]>=35){
      echo "You are obese class II.";
      }
      elseif($_SESSION["BMI"]>=30){
      echo "You are obese class I.";   
      }
      else{
          echo "You are overweight.";

      }
  }
}?></h4>
    
  Obesity is a complex disease involving an excessive amount of body fat. Obesity isn't just a cosmetic concern. It's a medical problem that increases the risk of other diseases and health problems, such as heart disease, diabetes, high blood pressure and certain cancers.
   <br><br><h3>Keep in mind:</h3>
   1. Manage your diet.<br>
   2. Perform physical activity.<br>
   3. Get restful sleep every night.<br>
   4. Manage stress.<br>
   
  <br>
<h3>Here's a list of doctors concerned with the same.</h3>
1. Doctor_1<br>
2. Doctor_2<br>
3. Doctor_3<br>
4. Doctor_4
</div>


<div class="container-sm " style="background-color:rgba(73, 96, 134, 0.292); border-radius: 00.9rem; box-shadow: 2px 2px 15px ; font-size: 20px; margin-top: 40px; padding: 20px 20px 20px 20px;margin-bottom: 40px;">
  <h2>Osteoporosis</h2>
  <h4><?php
  $_SESSION["osteoporosis_percentage"] = cal_percentage($_SESSION["int_nfr_op"] , $_SESSION["total_osteoporosis"]);
   echo "Chances of you suffering from Osteoporosis : ".$_SESSION["osteoporosis_percentage"].'%<br/>';?></h4>  
  Osteoporosis causes bones to become weak and brittle — so brittle that a fall or even mild stresses such as bending over or coughing can cause a fracture. Osteoporosis-related fractures most commonly occur in the hip, wrist or spine.
   <br><br><h3>Keep in mind:</h3>
   1. Quit Smoking.<br>
   2. Perform physical activity.<br>
   3. Do exercise regularly.<br>
   4. Best to get your calcium from foods.<br>
   
  <br>
<h3>Here's a list of doctors concerned with the same.</h3>
1. Doctor_1<br>
2. Doctor_2<br>
3. Doctor_3<br>
4. Doctor_4<br>
</div>

<form method=post action="postdisease.php">
      <div class="container-sm " style="background-color:rgba(73, 96, 134, 0.292); border-radius: 00.9rem; box-shadow: 2px 2px 15px ; font-size: 20px; margin-top: 40px; padding: 20px 20px 20px 20px;margin-bottom: 40px;">
    <label style="margin-bottom: 10px; font-size: 20px; margin-top: 20px; font-size: 30px;margin-left: 20px;">
      Do you want us to store this information?</label><br>

      <div class="form-check" style="margin-left: 28px; font-size: 20px;">
    <input class="form-check-input" type="checkbox" value="yes" name="store" id="flexCheckDefault" required>
    <label class="form-check-label" for="flexCheckDefault" style="margin-bottom: 20px;">
      Yes
      </label>
    </div>
    
    
  
    <button type="submit" class="btn btn-primary" style="margin-left:auto;margin-right:auto;display:block ;background-color: #516392 ;  
          color:white;
          padding: 0.7rem 1.5rem;
          font-size: 1rem; 
          
          border-radius: 0.7rem" >Upload</button>

</form>
    </div>
    





    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>
  </body>
</html>
              
  



    



  




  