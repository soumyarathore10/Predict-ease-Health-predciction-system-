<?php
session_start();

include 'connection.php';
if($_SERVER['REQUEST_METHOD'] == 'POST'){
    
    $firstname = $_POST['firstname'];
    $lastname = $_POST['lastname'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $cpassword = $_POST['confirm_password'];
    $_SESSION["email"]=$email;

    

  
    
 
    
    
if(isset($_POST['email']) && isset($_POST['password'])){
    $uppercase = preg_match('@[A-Z]@', $password);
    $lowercase = preg_match('@[a-z]@', $password);
    $number    = preg_match('@[0-9]@', $password);

    if(!$uppercase || !$lowercase || !$number || strlen($password) < 8 || strlen($password) > 20){
        echo '<script>window.alert("Password should be at least 8-20 characters in length and should include at least one uppercase letter, one lowercase letter and one number")</script>';
    }
    else{
    if($password===$cpassword){
    $sqli = "SELECT * FROM `info` WHERE email = '$email' AND password = '$password'"; 
    $out = mysqli_query($con,$sqli);   
    $nfr = mysqli_num_rows($out);
    if($out){
        if($nfr){
            echo "<meta http-equiv='refresh' content='0'>";
            echo '<script>window.alert("That email already exists")</script>';
        }
        else{
        $sql = "INSERT INTO `info`(`firstname`, `lastname`, `email`, `password`) VALUES ('$firstname','$lastname','$email','$password')";
    $result = mysqli_query($con,$sql);
    if($result){
            header("location:lobby.html");
        }else{
            echo '<script>alert("Something went wrong!")</script>';
        }
    }
}
    }
    else{
        echo '<script>alert("Passwords did not match")</script>';
    }
}
}
}




?>