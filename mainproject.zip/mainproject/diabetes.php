<?php
// Start the session
session_start();

//Connnection
$host="localhost";
$user="root";
$password='';
$db_name="prediction";


$con=mysqli_connect($host,$user,$password,$db_name);
if(mysqli_connect_errno()){
    die("failed to connect with mysql".mysqli_connect_error());
    
}

if($_SERVER['REQUEST_METHOD'] == 'POST'){
    if(isset($_POST['micturition']) && isset($_POST['thirsty']) && isset($_POST['hungry']) && isset($_POST['blurry_vision']) && isset($_POST['slow_healing']) && isset($_POST['weightloss']) && isset($_POST['numbness']))
    {
    $_SESSION["total_diabetes"]=7;
    $micturition = $_POST['micturition'];
    $thirsty = $_POST['thirsty'];
    $hungry = $_POST['hungry'];
    $blurry_vision = $_POST['blurry_vision'];
    $slow_healing = $_POST['slow_healing'];
    $weightloss = $_POST['weightloss'];
    $numbness = $_POST['numbness'];

    $sql = "SELECT * FROM `predict` WHERE symptom = '$micturition' OR symptom = '$thirsty' OR symptom = '$hungry' OR symptom = '$blurry_vision' OR symptom = '$slow_healing' OR symptom = '$weightloss' OR symptom = '$numbness'";
    $result = mysqli_query($con,$sql);
    $nfr = mysqli_num_rows($result);
    $_SESSION["int_nfr_db"]= (float)$nfr;

    // function cal_percentage($num_amount, $num_total) {
    //     $count1 = $num_amount / $num_total;
    //     $count2 = $count1 * 100;
    //     $count = number_format($count2, 0);
    //     return $count;
    // }
    // $_SESSION["diabetes_percentage"] = cal_percentage($_SESSION["int_nfr_db"], $_SESSION["total_diabetes"]);


    if($result){
    // echo "Chances of you having High Blood Pressure : ".$_SESSION["diabetes_percentage"].'%<br/>';
    header("location:PCOD.html");


    }
    }
}



?>