<?php
// Start the session
session_start();
?>

<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>View user.</title>
    <link rel="icon" href="titlelogowhite.png" type="image/icon type">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
  </head>
  <body style="background-color: #51649237">
    <nav class="navbar navbar-expand-lg navbar-light"  style="background-color: #516392;">
      <a class="navbar-brand mx-3" href="#">
        <img class="logo" src="Predict-ease -logos__white.png" alt="\Stuff logo" style="width: 160px;
      height: 40px;">
    </a>
    <button 
        class="navbar-toggler" 
        type="button" 
        data-bs-toggle="collapse" 
        data-bs-target="#navbarSupportedContent" 
        aria-controls="navbarSupportedContent" 
        aria-expanded="false" 
        aria-label="Toggle navigation"
        >
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav me-auto mb-2 mb-lg-0">
            <li class="nav-item">
            
              <a class="nav-link "  href="admin.html" style="color: #e0e2d5;">Admin Lobby</a>
              </li>
                
              
          </ul>
         
        </div>
  </nav>


  <div class="px-4 py-2" style="margin-top:20px;">
    <h1 class="display-5 fw-bold " style="font-size: 50px; ">View user details.</h1>
    </div>
    <div class="col-lg-6 mx-4 ">
      <div class=" mb-4 " style="font-size: 22px; margin-top: 0px;">Enter the user's email address you want to search details for.</div>
 
    </div>
    <div class="container-sm " style="background-color:rgba(73, 96, 134, 0.292); border-radius: 00.9rem; box-shadow: 2px 2px 15px ;" >
  <form method="post" action="">
        <div class="mb-3">
        <label style="margin-bottom:10px; font-size:20px; margin-top:20px;font-size: 30px;margin-left: 20px" >  Enter email address.</label><br>
        <input type="email" name="email" id="name" placeholder="Enter email." style="margin-bottom:20px;margin-left: 20px" required>
    </div>
  </div>

  
<div class="mb-3">
  <div class="text-center py-3">
    <button type="submit" class="btn" style="border-color: #e0e2d5; color: #e0e2d5; background-color: #516392; font-size: 20px; margin-top: 10px;padding: 10px 30px 10px 30px;">Search</button></a>
  </div>
</div>
</form>

<div class="container-sm " style="background-color:rgba(73, 96, 134, 0.292);  box-shadow: 2px 2px 15px ; padding: 10px 10px 10px 10px; margin-bottom: 40px ">
<table class="table table-bordered">
  <thead>
    <tr>
      <th scope="col">ID</th>
      <th scope="col">Email</th>
      <th scope="col">Name</th>
      <th scope="col">Age</th>
      <th scope="col">Height(cm)</th>
      <th scope="col">Weight(kg)</th>
      <th scope="col">Gender</th>
      <th scope="col">Blood Pressure(%)</th>
      <th scope="col">Diabetes(%)</th>
      <th scope="col">PCOD(%)</th>
      <th scope="col">Obesity(%)</th>
      <th scope="col">Osteoporosis(%)</th>
      <th scope="col">Date and Time</th>
    </tr>
  </thead>
    </div>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>



  <?php
//Connnection
$host="localhost";
$user="root";
$password='';
$db_name="prediction";


$con=mysqli_connect($host,$user,$password,$db_name);
if(mysqli_connect_errno()){
    die("failed to connect with mysql".mysqli_connect_error());
    
}

if($_SERVER['REQUEST_METHOD'] == 'POST'){
    if(isset($_POST['email']))
    {
    
    $email = $_POST['email'];
    // $symptom1 = $_POST['symptom1'];
    // $symptom2 = $_POST['symptom2'];
    // $symptom3 = $_POST['symptom3'];
    // $symptom4 = $_POST['symptom4'];
    // $symptom5 = $_POST['symptom5'];
    

    $sql = "SELECT * FROM `b_info` WHERE email = '$email'";
    $result = mysqli_query($con,$sql);
    $nfr = mysqli_num_rows($result);
    

  
    if($nfr!=0){
      
      while($fetch=mysqli_fetch_assoc($result))
      {
        echo "
        <tbody>
        <tr>
        <td>".$fetch['id']."</td>
        <td>".$fetch['email']."</td>
        <td>".$fetch['name']."</td>
        <td>".$fetch['age']."</td>
        <td>".$fetch['height']."</td>
        <td>".$fetch['weight']."</td>
        <td>".$fetch['gender']."</td>
        <td>".$fetch['blood_pressure']."</td>
        <td>".$fetch['diabetes']."</td>
        <td>".$fetch['PCOD']."</td>
        <td>".$fetch['obesity']."</td>
        <td>".$fetch['osteoporosis']."</td>
        <td>".$fetch['date_time']."</td>";
        
        

      }
        
    }
    else{
      echo '<script>alert("No records found.")</script>';

    }

    }
}



?>
</table>
</body>
</html>



