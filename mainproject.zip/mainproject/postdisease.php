<?php
session_start();



$host="localhost";
$user="root";
$password='';
$db_name="prediction";


$con=mysqli_connect($host,$user,$password,$db_name);
if(mysqli_connect_errno()){
    die("failed to connect with mysql".mysqli_connect_error());
    
}
if($_SERVER['REQUEST_METHOD'] == 'POST'){
    if(isset($_POST['store'])){
    {
            $email = $_SESSION["email"];
            $name = $_SESSION["name"];
            $age = $_SESSION["age"];
            $height = $_SESSION["height"];
            $weight = $_SESSION["weight"];
            $gender = $_SESSION["gender"];
            $blood_pressure = (int)$_SESSION["bp_percentage"];
            $diabetes = (int)$_SESSION["diabetes_percentage"];
            $PCOD = (int)$_SESSION["PCOD_percentage"];
            $obesity= (int)$_SESSION["obesity_percentage"];
            $osteoporosis = (int)$_SESSION["osteoporosis_percentage"];
        }

    
    
    
    $sql = "INSERT INTO `b_info` (`email`, `name`, `age`, `height`, `weight`, `gender`, `blood_pressure`, `diabetes`, `PCOD`, `obesity`, `osteoporosis`) VALUES ('$email', '$name', '$age', '$height', '$weight', '$gender', '$blood_pressure', '$diabetes', '$PCOD', '$obesity', '$osteoporosis')";

    $result = mysqli_query($con,$sql);
    if($result){
        
        echo '<script>alert("Successfully added! Thank You for using Predict-ease.")</script>';
    }
    }
    // else{
    //     header("location:lobby.html");
    // }
}
?>