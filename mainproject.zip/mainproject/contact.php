<?php
$host="localhost";
$user="root";
$password='';
$db_name="contact";
// Create connection
$con = mysqli_connect($host,$user,$password,$db_name);
// Check connection
if (!$con) {
      die("Connection failed: " . mysqli_connect_error());
}
 
echo "Connected successfully";
 
if($_SERVER['REQUEST_METHOD'] == 'POST'){
$email = $_POST['email_id'];
$query = $_POST['query'];

$sql = "INSERT INTO queries (email_id, query) VALUES ('$email','$query')";
$result = mysqli_query($con,$sql);
if($result){
        header("Location:login.php");
    }else{
        header("location:sign_up.html");
    }
}
