<?php
// Start the session
session_start();

//Connnection
$host="localhost";
$user="root";
$password='';
$db_name="prediction";


$con=mysqli_connect($host,$user,$password,$db_name);
if(mysqli_connect_errno()){
    die("failed to connect with mysql".mysqli_connect_error());
    
}

//<---------->



//Blood Pressure

if($_SERVER['REQUEST_METHOD'] == 'POST'){
if(isset($_POST['headache']) && isset($_POST['nosebleed']) && isset($_POST['chestpain']) && isset($_POST['heartbeat']) && isset($_POST['vertigo']) && isset($_POST['nausea']) && isset($_POST['fatigue']) && isset($_POST['diff_breathing']) && isset($_POST['sweating']))
{   
    $_SESSION["total_bp"]=9;
    $headache  = $_POST['headache'];
    $nosebleed  = $_POST['nosebleed'];
    $chestpain  = $_POST['chestpain'];
    $heartbeat  = $_POST['heartbeat'];
    $vertigo  = $_POST['vertigo'];
    $nausea  = $_POST['nausea'];
    $fatigue = $_POST['fatigue'];
    $diff_breathing = $_POST['diff_breathing'];
    $sweating = $_POST['sweating'];
    
    $query = "SELECT * FROM `predict` WHERE symptom = '$headache' OR symptom = '$nosebleed' OR symptom = '$chestpain' OR symptom = '$heartbeat' OR symptom = '$vertigo' OR symptom = '$nausea' OR symptom = '$fatigue' OR symptom = '$diff_breathing' OR symptom = '$sweating'";
  
    $query_run = mysqli_query($con, $query);
   
    $nfr = mysqli_num_rows($query_run);
//     if(isset($_POST['heart_disease'])){
//         $int_nfr= (float)$nfr+1;
    
//     function cal_percentage($num_amount, $num_total) {
//         $count1 = $num_amount / $num_total;
//         $count2 = $count1 * 100;
//         $count = number_format($count2, 0);
//         return $count;
//     }
//     $_SESSION["bp_percentage"] = cal_percentage($int_nfr, $total_bp);


//     if($query_run)
//     {
    
//         header("location:diabetes.html");
//     }
// }
// else{  
    $_SESSION["int_nfr_bp"]= (float)$nfr;
    
    // function cal_percentage($num_amount, $num_total) {
    //     $count1 = $num_amount / $num_total;
    //     $count2 = $count1 * 100;
    //     $count = number_format($count2, 0);
    //     return $count;
    // }
    // $_SESSION["bp_percentage"] = cal_percentage($_SESSION["int_nfr_bp"], $_SESSION["total_bp"]);


    if($query_run)
    {
    
        header("location:diabetes.html");
    }
}
}








?>
