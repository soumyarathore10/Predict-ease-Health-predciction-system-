<?php
// Start the session
session_start();

//Connnection
$host="localhost";
$user="root";
$password='';
$db_name="prediction";


$con=mysqli_connect($host,$user,$password,$db_name);
if(mysqli_connect_errno()){
    die("failed to connect with mysql".mysqli_connect_error());
    
}

if($_SERVER['REQUEST_METHOD'] == 'POST'){
    if(isset($_POST['name']) && isset($_POST['symptom1']) && isset($_POST['symptom2']) && isset($_POST['symptom3']) && isset($_POST['symptom4']) && isset($_POST['symptom5']))
    {
    
    $name = $_POST['name'];
    $symptom1 = $_POST['symptom1'];
    $symptom2 = $_POST['symptom2'];
    $symptom3 = $_POST['symptom3'];
    $symptom4 = $_POST['symptom4'];
    $symptom5 = $_POST['symptom5'];
    

    $sql="INSERT INTO `predict` ( `name`, `symptom`) VALUES ( '$name', '$symptom1'), ( '$name', '$symptom2'), ('$name', '$symptom3'), ( '$name', '$symptom4'), ( '$name', '$symptom5')";


    
  
    $result = mysqli_query($con,$sql);
    if($result){
       
        echo '<script>alert("Added succesfully")</script>';
    }

    }
}



?>