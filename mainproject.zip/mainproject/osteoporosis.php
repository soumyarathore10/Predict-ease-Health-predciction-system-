<?php
// Start the session
session_start();

//Connnection
$host="localhost";
$user="root";
$password='';
$db_name="prediction";


$con=mysqli_connect($host,$user,$password,$db_name);
if(mysqli_connect_errno()){
    die("failed to connect with mysql".mysqli_connect_error());
    
}

if($_SERVER['REQUEST_METHOD'] == 'POST'){
    if(isset($_POST['loss_of_height']) && isset($_POST['brittle_bones']) && isset($_POST['change_in_posture']))
    {
    $_SESSION["total_osteoporosis"]=3;
    $loss_of_height = $_POST['loss_of_height'];
    $brittle_bones = $_POST['brittle_bones'];
    $change_in_posture = $_POST['change_in_posture'];
    

    $sql = "SELECT * FROM `predict` WHERE symptom = '$loss_of_height' OR symptom = '$brittle_bones' OR symptom = '$change_in_posture'";
    $result = mysqli_query($con,$sql);
    $nfr = mysqli_num_rows($result);
    $_SESSION["int_nfr_op"]= (float)$nfr;

    // function cal_percentage($num_amount, $num_total) {
    //     $count1 = $num_amount / $num_total;
    //     $count2 = $count1 * 100;
    //     $count = number_format($count2, 0);
    //     return $count;
    // }
    // $_SESSION["osteoporosis_percentage"] = cal_percentage($_SESSION["int_nfr_op"], $_SESSION["total_osteoporosis"]);


    if($result){
    // echo "Chances of you having High Blood Pressure : ".$_SESSION["diabetes_percentage"].'%<br/>';
    header("location:obesity.html");


    }
    }
}



?>