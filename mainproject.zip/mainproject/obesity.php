<?php
// Start the session
session_start();

//Connnection
$host="localhost";
$user="root";
$password='';
$db_name="prediction";


$con=mysqli_connect($host,$user,$password,$db_name);
if(mysqli_connect_errno()){
    die("failed to connect with mysql".mysqli_connect_error());
    
}

if($_SERVER['REQUEST_METHOD'] == 'POST'){
    if(isset($_POST['excess_bodyfat']) && isset($_POST['snoring']) && isset($_POST['flat_feet']) && isset($_POST['skin_problems']))
    {
    $_SESSION["total_obesity"]=4;
    $excess_bodyfat = $_POST['excess_bodyfat'];
    $snoring = $_POST['snoring'];
    $flat_feet = $_POST['flat_feet'];
    $skin_problems = $_POST['skin_problems'];
    

    $sql = "SELECT * FROM `predict` WHERE symptom = '$excess_bodyfat' OR symptom = '$snoring' OR symptom = '$flat_feet' OR symptom = '$skin_problems'";
    $result = mysqli_query($con,$sql);
    $nfr = mysqli_num_rows($result);
    $_SESSION["int_nfr_ob"]= (float)$nfr;


    if($result){
    // echo "Chances of you having High Blood Pressure : ".$_SESSION["diabetes_percentage"].'%<br/>';
    header("location:advanceuserinfo5.html");


    }
    }
}



?>