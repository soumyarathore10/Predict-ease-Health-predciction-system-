<?php
session_start();



$host="localhost";
$user="root";
$password='';
$db_name="prediction";


$con=mysqli_connect($host,$user,$password,$db_name);
if(mysqli_connect_errno()){
    die("failed to connect with mysql".mysqli_connect_error());
    
}
if($_SERVER['REQUEST_METHOD'] == 'POST'){
    if(isset($_POST['name']) && isset($_POST['age']) && isset($_POST['height']) && isset($_POST['weight']) && isset($_POST['gender']))
    {   
    $name = $_POST['name'];
    $age = $_POST['age'];
    $height = $_POST['height'];
    $weight = $_POST['weight'];
    $gender = $_POST['gender'];
    $_SESSION["name"]=$name;
    $_SESSION["age"]=$age;
    $_SESSION["height"]=$height;
    $_SESSION["weight"]=$weight;
    $_SESSION["gender"]=$gender;
    
    $sql = "INSERT INTO `b_info` (`name`, `age`, `height`, `weight`, `gender`) VALUES ('$name', '$age', '$height', '$weight', '$gender')";

    $result = mysqli_query($con,$sql);
    if($result){
        header("location:blood_pressure.html");
$_SESSION["age"]=$age;
$_SESSION["height_meters"]=(float)($height*(0.01));
$_SESSION["height_squared"]=(float)($_SESSION["height_meters"]*$_SESSION["height_meters"]);
$_SESSION["weight"]=(float)($weight);
// $_SESSION["BMI"]=(float)($_SESSION["weight"]/$_SESSION["height_squared"]);
// echo $_SESSION["BMI"];
// if($_SESSION["age"]>=12){
//     if($_SESSION["BMI"]>18.5 && $_SESSION["BMI"]<=25){
//         echo "You are fit";
//     }
//     if($_SESSION["BMI"]<18.5){
//       if($_SESSION["BMI"]>16){
//         echo "You are thin";
//     }
//     else{
//       echo "you are severly thin";
//     }
// }
//     if($_SESSION["BMI"]>25){
//         if($_SESSION["BMI"]>=40){
//             echo "You are obese class III.";
//         }
//         elseif($_SESSION["BMI"]>=35){
//         echo "You are obese class II.";
//         }
//         elseif($_SESSION["BMI"]>=30){
//         echo "You are obese class I.";   
//         }
//         else{
//             echo "You are overweight.";

//         }
//     }
// }

   


    }
}
}

?>