<?php
$host="localhost";
$user="root";
$password='';
$db_name="admin";


$con=mysqli_connect($host,$user,$password,$db_name);
if(mysqli_connect_errno()){
    die("failed to connect with mysql".mysqli_connect_error());
    
}

if($_SERVER['REQUEST_METHOD'] == 'POST'){
    if(isset($_POST['email']) && isset($_POST['password'])){
    $email = $_POST['email'];
    $password = $_POST['password'];
    $sql = "SELECT * FROM `info_admin` WHERE `email` = '$email' AND `password` = '$password'";
    $result = mysqli_query($con,$sql);
    $nfr = mysqli_num_rows($result);
    if($result){
       
        if($nfr){
             header("Location:admin.html");
        }
       
    }
    else{
        echo '<script>alert("Wrong Credentials!")</script>';
      }
  }
}

?>