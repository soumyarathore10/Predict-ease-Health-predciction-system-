<?php
session_start();

include 'connection.php';
if($_SERVER['REQUEST_METHOD'] == 'POST'){
    if(isset($_POST['email']) && isset($_POST['password'])){
    $email = $_POST['email'];
    $password = $_POST['password'];
    $_SESSION["email"]=$email;
    $sql = "SELECT * FROM `info` WHERE email = '$email' AND password = '$password'";
    $result = mysqli_query($con,$sql);
    $nfr = mysqli_num_rows($result);
    if($result){
        if($nfr){
             header("Location:lobby.html");
        }
        else{
          echo '<script>alert("Wrong Credentials!")</script>';
        }
        
    }
  }
}